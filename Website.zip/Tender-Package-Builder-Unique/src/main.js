
import './style.css';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

const state={lang:'en',tender:null,requirements:[],files:[],busy:false,message:'',messageType:'info',query:'',filter:'all'};
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const T={
en:{app:'TenderFlow',tag:'Tender package workspace',sub:'A clean, browser-only workspace for checking, matching and building tender documents.',
load:'Load requirements',add:'Add PDFs',lang:'বাংলা',overview:'Workspace',check:'Document checklist',files:'Uploaded files',
total:'Total',matched:'Matched',included:'Included',issues:'Issues',deadline:'Submission deadline',bidder:'Bidder',
entity:'Procuring entity',generate:'Build final PDF',building:'Building…',ready:'Ready',missing:'Missing',expired:'Expired',
expiry:'Expiry needed',duplicate:'Duplicate',optional:'Optional',required:'Required',select:'Select a PDF…',
drop:'Drop PDF files here',limits:'PDF only • 30 files • 50 MB total',pages:'pages',remove:'Remove',noFiles:'No PDFs yet.',
start:'Start with your tender requirements',startText:'Load the requirements JSON to open your tender workspace.',
choose:'Choose JSON',search:'Search documents…',all:'All',problem:'Needs attention',done:'Matched',
notProvided:'Not provided',notReq:'Not required',success:'Package created and downloaded.',badJson:'Invalid requirements JSON.',
badPdf:'This PDF could not be read.',tooMany:'Maximum 30 files.',tooLarge:'Total size cannot exceed 50 MB.',
onlyPdf:'Only PDF files are accepted.',readyMsg:'Requirements loaded.'},
bn:{app:'TenderFlow',tag:'টেন্ডার প্যাকেজ ওয়ার্কস্পেস',sub:'ব্রাউজারেই টেন্ডার ডকুমেন্ট যাচাই, ম্যাচ ও PDF প্যাকেজ তৈরি করুন।',
load:'রিকোয়ারমেন্ট লোড',add:'PDF যোগ করুন',lang:'English',overview:'ওয়ার্কস্পেস',check:'ডকুমেন্ট চেকলিস্ট',files:'আপলোড করা ফাইল',
total:'মোট',matched:'ম্যাচ',included:'অন্তর্ভুক্ত',issues:'সমস্যা',deadline:'জমাদানের শেষ তারিখ',bidder:'বিডার',
entity:'ক্রয়কারী প্রতিষ্ঠান',generate:'ফাইনাল PDF তৈরি',building:'তৈরি হচ্ছে…',ready:'প্রস্তুত',missing:'অনুপস্থিত',expired:'মেয়াদ শেষ',
expiry:'মেয়াদ দরকার',duplicate:'ডুপ্লিকেট',optional:'ঐচ্ছিক',required:'আবশ্যক',select:'PDF নির্বাচন করুন…',
drop:'এখানে PDF ছেড়ে দিন',limits:'শুধু PDF • ৩০ ফাইল • ৫০ MB',pages:'পৃষ্ঠা',remove:'মুছুন',noFiles:'এখনো PDF নেই।',
start:'আপনার টেন্ডার দিয়ে শুরু করুন',startText:'রিকোয়ারমেন্ট JSON লোড করলে ওয়ার্কস্পেস খুলবে।',choose:'JSON নির্বাচন',
search:'ডকুমেন্ট খুঁজুন…',all:'সব',problem:'সমস্যা আছে',done:'ম্যাচ হয়েছে',notProvided:'দেওয়া হয়নি',notReq:'প্রয়োজন নেই',
success:'প্যাকেজ তৈরি ও ডাউনলোড হয়েছে।',badJson:'রিকোয়ারমেন্ট JSON সঠিক নয়।',badPdf:'PDF পড়া যায়নি.',tooMany:'সর্বোচ্চ ৩০টি ফাইল।',
tooLarge:'মোট ফাইল ৫০ MB-এর বেশি হতে পারবে না।',onlyPdf:'শুধু PDF গ্রহণ করা হবে।',readyMsg:'রিকোয়ারমেন্ট লোড হয়েছে।'}
};
const tr=k=>T[state.lang][k]??k;

function status(r){
 const f=state.files.find(x=>x.id===r.fileId);
 if(!f) return r.mandatory?{l:tr('missing'),c:'bad',block:true}:{l:tr('notProvided'),c:'neutral',block:false};
 if(f.duplicate)return{l:tr('duplicate'),c:'bad',block:true};
 if(r.has_expiry&&!r.expiryDate)return{l:tr('expiry'),c:'bad',block:true};
 if(r.has_expiry&&r.expiryDate<state.tender.submission_deadline)return{l:tr('expired'),c:'bad',block:true};
 return{l:tr('ready'),c:'ok',block:false};
}
function counts(){
 const issues=state.requirements.filter(r=>status(r).block).length;
 const matched=state.requirements.filter(r=>r.fileId).length;
 const included=state.requirements.filter(r=>r.fileId&&!status(r).block).length;
 return {issues,matched,included,total:state.requirements.length};
}
function flash(m,type='info'){state.message=m;state.messageType=type;render();setTimeout(()=>{if(state.message===m){state.message='';render()}},3000)}

function render(){
 document.documentElement.lang=state.lang;
 const c=counts();
 if(!state.tender){$('#app').innerHTML=`<div class="app"><aside class="sidebar">${sidebar()}</aside><main class="main">
 <section class="start"><div class="startLogo">TF</div><h2>${tr('start')}</h2><p>${tr('startText')}</p>
 <label class="btn primary">${tr('choose')}<input id="jsonStart" type="file" accept=".json,application/json" hidden></label>
 <div class="hint">TenderFlow • 100% client-side processing</div></section></main></div>`;bind();return}
 const pct=c.total?Math.round(c.included/c.total*100):0;
 const filtered=state.requirements.filter(r=>{
   const title=state.lang==='bn'?(r.title_bn||r.title_en):(r.title_en||r.title_bn);
   const q=state.query.toLowerCase();
   const hit=!q||title.toLowerCase().includes(q)||r.id.toLowerCase().includes(q);
   const s=status(r); const f=state.filter;
   return hit&&(f==='all'||(f==='problem'&&s.block)||(f==='done'&&!s.block&&r.fileId));
 });
 $('#app').innerHTML=`<div class="app"><aside class="sidebar">${sidebar()}</aside><main class="main">
 <header class="top"><div><div class="kicker">${tr('tag')}</div><h1>${esc(state.tender.title||'Tender')}</h1><p class="subtitle">${tr('sub')}</p></div>
 <div class="actions"><button class="btn" id="lang">${tr('lang')}</button><label class="btn">${tr('load')}<input id="json" type="file" accept=".json,application/json" hidden></label><label class="btn primary">${tr('add')}<input id="pdf" type="file" accept=".pdf,application/pdf" multiple hidden></label></div></header>
 ${state.message?`<div class="toast ${state.messageType}">${esc(state.message)}</div>`:''}
 <section class="hero"><div><div class="tenderId">${esc(state.tender.tender_id||'TENDER')}</div><h2>${esc(state.tender.title||'Tender')}</h2><p>${esc(state.tender.procuring_entity||'')}</p></div>
 <div class="heroMeta"><div class="meta"><small>${tr('bidder')}</small><b>${esc(state.tender.bidder||'—')}</b></div><div class="meta"><small>${tr('deadline')}</small><b>${esc(state.tender.submission_deadline||'—')}</b></div></div></section>
 <section class="stats"><div class="stat"><small>${tr('total')}</small><strong>${c.total}</strong></div><div class="stat"><small>${tr('matched')}</small><strong>${c.matched}</strong></div>
 <div class="stat good"><small>${tr('included')}</small><strong>${c.included}</strong></div><div class="stat ${c.issues?'bad':'good'}"><small>${tr('issues')}</small><strong>${c.issues}</strong></div></section>
 <div class="layout"><section class="panel"><div class="panelHead"><div><h3>${tr('check')}</h3><p>${pct}% ${tr('included').toLowerCase()}</p></div>
 <button class="btn primary" id="generate" ${c.issues||state.busy?'disabled':''}>${state.busy?tr('building'):tr('generate')}</button></div><div class="progress"><i style="width:${pct}%"></i></div>
 <div class="filters"><input class="search" id="search" value="${esc(state.query)}" placeholder="${tr('search')}"><select class="filter" id="filter">
 <option value="all" ${state.filter==='all'?'selected':''}>${tr('all')}</option><option value="problem" ${state.filter==='problem'?'selected':''}>${tr('problem')}</option><option value="done" ${state.filter==='done'?'selected':''}>${tr('done')}</option></select></div>
 <div class="tableWrap"><table><thead><tr><th>#</th><th>${tr('check')}</th><th>${tr('files')}</th><th>${tr('expiry')}</th></tr></thead><tbody>
 ${filtered.map((r,i)=>row(r,i)).join('')||`<tr><td colspan="4"><div class="empty">No matching documents.</div></td></tr>`}</tbody></table></div></section>
 <aside class="panel"><div class="panelHead"><div><h3>${tr('files')}</h3><p>${state.files.length}/30</p></div></div>
 <label class="drop" id="drop"><input id="pdf2" type="file" accept=".pdf,application/pdf" multiple hidden><div><div class="dropIcon">↑</div><strong>${tr('drop')}</strong><span>${tr('limits')}</span></div></label>
 <div class="files">${state.files.length?state.files.map(fileRow).join(''):`<div class="empty">${tr('noFiles')}</div>`}</div></aside></div>
 </main></div>`;
 bind();
}
function sidebar(){return `<div class="logo"><div class="logoMark">TF</div><div><b>TenderFlow</b><span>Package Builder</span></div></div><nav class="nav"><button class="active"><span class="navIcon">◈</span>${tr('overview')}</button><button><span class="navIcon">✓</span>${tr('check')}</button><button><span class="navIcon">▣</span>${tr('files')}</button></nav><div class="sideBottom">Your files stay in this browser. Nothing is sent to a server.<button class="lang" id="sideLang">${tr('lang')}</button></div>`}
function row(r,i){
 const s=status(r),f=state.files.find(x=>x.id===r.fileId),title=state.lang==='bn'?(r.title_bn||r.title_en):(r.title_en||r.title_bn);
 return `<tr><td><span class="order">${r.order??i+1}</span></td><td><span class="status ${s.c}"><i></i>${s.l}</span></td><td><div class="doc"><b>${esc(title)}</b><span class="${r.mandatory?'':'optional'}">${r.mandatory?tr('required'):tr('optional')}</span></div>
 <select data-req="${esc(r.id)}"><option value="">${tr('select')}</option>${state.files.map(x=>`<option value="${x.id}" ${r.fileId===x.id?'selected':''} ${x.duplicate&&r.fileId!==x.id?'disabled':''}>${esc(x.name)}${x.duplicate?' • '+tr('duplicate'):''}</option>`).join('')}</select></td>
 <td>${r.has_expiry?(f?`<input class="date" data-expiry="${r.id}" type="date" value="${r.expiryDate||''}">`:`<span style="color:#52667d">—</span>`):`<span style="color:#52667d">${tr('notReq')}</span>`}</td></tr>`;
}
function fileRow(f){return `<div class="file"><span class="pdf">PDF</span><div class="fileMain"><b title="${esc(f.name)}">${esc(f.name)}</b><span>${f.pages??'—'} ${tr('pages')}${f.duplicate?' • '+tr('duplicate'):''}</span></div><button class="remove" data-remove="${f.id}" title="${tr('remove')}">×</button></div>`}
async function loadJSON(file){
 try{const d=JSON.parse(await file.text());if(!d?.tender||!Array.isArray(d.requirements))throw 0;
 state.tender=d.tender;state.requirements=d.requirements.map(r=>({...r,fileId:null,expiryDate:''})).sort((a,b)=>(a.order||0)-(b.order||0));state.files=[];flash(tr('readyMsg'),'success')
 }catch{flash(tr('badJson'),'error')}
}
async function addPDFs(list){
 const incoming=[...list];if(!incoming.length)return;
 if(state.files.length+incoming.length>30)return flash(tr('tooMany'),'error');
 if(state.files.reduce((a,f)=>a+f.size,0)+incoming.reduce((a,f)=>a+f.size,0)>50*1024*1024)return flash(tr('tooLarge'),'error');
 for(const file of incoming){
  if(file.type!=='application/pdf'&&!file.name.toLowerCase().endsWith('.pdf')){flash(`${file.name}: ${tr('onlyPdf')}`,'error');continue}
  try{const buf=await file.arrayBuffer(),hash=await sha256(buf),pdf=await pdfjsLib.getDocument({data:buf.slice(0)}).promise;
   const duplicate=state.files.some(f=>f.hash===hash);state.files.push({id:crypto.randomUUID(),name:file.name,size:file.size,bytes:buf,pages:pdf.numPages,hash,duplicate});
   if(duplicate)state.files.forEach(f=>{if(f.hash===hash)f.duplicate=true})
  }catch{flash(`${file.name}: ${tr('badPdf')}`,'error')}
 }
 render()
}
async function sha256(buf){const h=await crypto.subtle.digest('SHA-256',buf);return [...new Uint8Array(h)].map(x=>x.toString(16).padStart(2,'0')).join('')}
function bind(){
 $('#lang')?.addEventListener('click',()=>{state.lang=state.lang==='en'?'bn':'en';render()});$('#sideLang')?.addEventListener('click',()=>{state.lang=state.lang==='en'?'bn':'en';render()});
 $('#jsonStart')?.addEventListener('change',e=>e.target.files[0]&&loadJSON(e.target.files[0]));$('#json')?.addEventListener('change',e=>e.target.files[0]&&loadJSON(e.target.files[0]));
 ['#pdf','#pdf2'].forEach(s=>$(s)?.addEventListener('change',e=>addPDFs(e.target.files)));
 $('#drop')?.addEventListener('click',()=>$('#pdf2')?.click());$('#drop')?.addEventListener('dragover',e=>{e.preventDefault();$('#drop').classList.add('drag')});$('#drop')?.addEventListener('dragleave',()=>$('#drop').classList.remove('drag'));$('#drop')?.addEventListener('drop',e=>{e.preventDefault();e.stopPropagation();$('#drop').classList.remove('drag');addPDFs(e.dataTransfer.files)});
 $('#search')?.addEventListener('input',e=>{state.query=e.target.value;render();const x=$('#search');x?.focus();x?.setSelectionRange(x.value.length,x.value.length)});
 $('#filter')?.addEventListener('change',e=>{state.filter=e.target.value;render()});
 document.querySelectorAll('select[data-req]').forEach(x=>x.addEventListener('change',e=>{const r=state.requirements.find(y=>y.id===e.target.dataset.req);const old=state.requirements.find(y=>y.fileId===e.target.value);if(old&&old!==r){old.fileId=null;old.expiryDate=''}r.fileId=e.target.value||null;if(!r.fileId)r.expiryDate='';render()}));
 document.querySelectorAll('[data-expiry]').forEach(x=>x.addEventListener('change',e=>{const r=state.requirements.find(y=>y.id===e.target.dataset.expiry);r.expiryDate=e.target.value;render()}));
 document.querySelectorAll('[data-remove]').forEach(x=>x.addEventListener('click',()=>{const id=x.dataset.remove;state.requirements.forEach(r=>{if(r.fileId===id){r.fileId=null;r.expiryDate=''}});state.files=state.files.filter(f=>f.id!==id);state.files.forEach(f=>f.duplicate=state.files.some(x=>x.id!==f.id&&x.hash===f.hash));render()}));
 $('#generate')?.addEventListener('click',generatePackage);
}
async function generatePackage(){
 state.busy=true;render();
 try{
  const out=await PDFDocument.create(),font=await out.embedFont(StandardFonts.Helvetica),bold=await out.embedFont(StandardFonts.HelveticaBold);
  const included=state.requirements.filter(r=>r.fileId&&!status(r).block),cover=out.addPage([595.28,841.89]),{width,height}=cover.getSize();
  cover.drawRectangle({x:0,y:height-130,width,height:130,color:rgb(.03,.07,.12)});cover.drawText('TENDERFLOW PACKAGE',{x:42,y:height-65,size:22,font:bold,color:rgb(1,1,1)});cover.drawText(state.tender.tender_id||'',{x:42,y:height-92,size:10,font,color:rgb(.45,.7,1)});
  let y=height-165;const meta=[['Tender Title',state.tender.title],['Procuring Entity',state.tender.procuring_entity],['Bidder',state.tender.bidder],['Submission Deadline',state.tender.submission_deadline],['Package Made',new Date().toISOString().slice(0,10)]];
  for(const [k,v] of meta){cover.drawText(k,{x:42,y,size:9,font:bold,color:rgb(.4,.45,.52)});cover.drawText(String(v||'—'),{x:175,y,size:10,font,color:rgb(.08,.1,.13)});y-=30}
  y-=12;cover.drawText('Included Documents',{x:42,y,size:14,font:bold,color:rgb(.04,.09,.15)});y-=25;
  for(const r of included){cover.drawText(`${r.order}. ${r.title_en||r.title_bn||r.id}`,{x:52,y,size:9,font,color:rgb(.1,.12,.15)});y-=18;if(y<70)break}
  for(const r of included){const f=state.files.find(x=>x.id===r.fileId),src=await PDFDocument.load(f.bytes),pages=await out.copyPages(src,src.getPageIndices());pages.forEach(p=>out.addPage(p))}
  const total=out.getPageCount();out.getPages().forEach((p,i)=>{const {width}=p.getSize(),txt=`${state.tender.tender_id} | Page ${i+1} of ${total}`;p.drawRectangle({x:0,y:0,width,height:20,color:rgb(1,1,1),opacity:.94});p.drawText(txt,{x:width/2-font.widthOfTextAtSize(txt,7)/2,y:6,size:7,font,color:rgb(.3,.34,.4)})});
  const bytes=await out.save(),a=document.createElement('a');a.href=URL.createObjectURL(new Blob([bytes],{type:'application/pdf'}));a.download=`${state.tender.tender_id||'Tender'}_Package.pdf`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1200);flash(tr('success'),'success')
 }catch(e){console.error(e);flash('Could not generate the PDF. Check the uploaded files.','error')}finally{state.busy=false;render()}
}
render();
